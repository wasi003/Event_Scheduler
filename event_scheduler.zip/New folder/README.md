# Event-Scheduler
A Flask-based Event Management web application. The project includes app.py, models, routes, templates, and static assets, with configuration and utilities. It uses an SQLite database (events.db), requirements.txt, and a bundled virtual environment, plus a related PDF document. Suitable for local de
